//
//  ViewController.swift
//  fakelocation
//
//  Created by lingchen on 2018/12/7.
//  Copyright © 2018 lingchen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

